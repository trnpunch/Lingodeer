import React, { Component } from "react";
import { View,Dimensions, Text } from "react-native";



const Window = {
  Width: Dimensions.get("window").width,
  Height: Dimensions.get("window").height
};


class Alphabet extends Component {
  static navigationOptions = {
    title: "Alphabet"
  };

  
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    console.log(Window.Width/10 )
    const {
      key,number
    } = this.props.navigation.state.params.type;
    return (
     
      <View style={{ justifyContent: "center", alignItems: "center",alignContent: "center", flex: 1 }}>
      <Text style={{ fontSize: 25 }}>{key} page is not finished.</Text>
      <Text style={{ fontSize: 25 }}> It’s a work in progress.</Text>
    </View>
    );
  }
}

export default Alphabet;
